from core import state
from core.localization import t
from core.ui import (
    success,
    warning,
    error
)

from database.queries import (
    is_blocked as database_is_blocked,
    is_blocked_between as database_is_blocked_between,
    create_block,
    delete_block,
    get_user_by_username
)


def is_blocked(user_uuid, other_uuid):

    return database_is_blocked(
        user_uuid,
        other_uuid
    )


def is_blocked_between(user_uuid, other_uuid):

    return database_is_blocked_between(
        user_uuid,
        other_uuid
    )


def block(*args):

    if state.current_user is None:

        error(
            t(
                "chat_account_required",
                state.settings
            )
        )

        return

    if (
        state.db is None
        or not state.db.is_connected()
    ):

        error(
            t(
                "block_database_required",
                state.settings
            )
        )

        return

    if len(args) != 1:

        warning(
            t(
                "block_usage",
                state.settings
            )
        )

        return

    username = args[0]

    user = get_user_by_username(
        username
    )

    if user is None:

        error(
            t(
                "block_user_not_found",
                state.settings
            )
        )

        return

    if user["uuid"] == state.current_user["uuid"]:

        error(
            t(
                "block_self",
                state.settings
            )
        )

        return

    if is_blocked(
        state.current_user["uuid"],
        user["uuid"]
    ):

        warning(
            t(
                "block_already",
                state.settings
            )
        )

        return

    if not create_block(
        state.current_user["uuid"],
        user["uuid"]
    ):

        error(
            t(
                "database_error",
                state.settings
            )
        )

        return

    success(
        t(
            "block_success",
            state.settings,
            username=user["username"]
        )
    )


def unblock(*args):

    if state.current_user is None:

        error(
            t(
                "chat_account_required",
                state.settings
            )
        )

        return

    if (
        state.db is None
        or not state.db.is_connected()
    ):

        error(
            t(
                "block_database_required",
                state.settings
            )
        )

        return

    if len(args) != 1:

        warning(
            t(
                "unblock_usage",
                state.settings
            )
        )

        return

    username = args[0]

    user = get_user_by_username(
        username
    )

    if user is None:

        error(
            t(
                "block_user_not_found",
                state.settings
            )
        )

        return

    if not delete_block(
        state.current_user["uuid"],
        user["uuid"]
    ):

        warning(
            t(
                "block_not_found",
                state.settings
            )
        )

        return

    success(
        t(
            "unblock_success",
            state.settings,
            username=user["username"]
        )
    )