from core import state
from core.localization import t
from core.ui import (
    style,
    warning,
    title
)


def show_plugins(*args):

    title(
        t(
            "plugins_title",
            state.settings
        )
    )

    if not state.loaded_plugins:

        warning(
            t(
                "plugins_empty",
                state.settings
            )
        )

        return

    for number, plugin in enumerate(
        state.loaded_plugins,
        1
    ):

        plugin_name = getattr(
            plugin,
            "PLUGIN_NAME",
            t(
                "plugin_unknown",
                state.settings
            )
        )

        plugin_version = getattr(
            plugin,
            "PLUGIN_VERSION",
            t(
                "plugin_unknown",
                state.settings
            )
        )

        plugin_author = getattr(
            plugin,
            "PLUGIN_AUTHOR",
            t(
                "plugin_unknown",
                state.settings
            )
        )

        print(
            style(
                "main",
                f"""│ {number}. {plugin_name}
│ {t("plugin_version", state.settings, version=plugin_version)}
│ {t("plugin_author", state.settings, author=plugin_author)}
│"""
            )
        )

    print(
        style(
            "success",
            t(
                "plugins_loaded",
                state.settings,
                amount=len(state.loaded_plugins)
            )
        )
    )