import os
import random
from datetime import datetime

from core import state
from core.localization import t, command_description
from core.ui import (
    style,
    success,
    title
)
from admin.access import is_admin

from database.queries import set_user_offline


def say_hi(*args):

    print(
        style(
            "main",
            t(
                "greeting",
                state.settings
            )
        )
    )


def cmd_clear(*args):

    os.system("clear")

    success(
        t(
            "console_cleared",
            state.settings
        )
    )


def cmd_time(*args):

    now = datetime.now()

    print(
        style(
            "main",
            t(
                "time",
                state.settings,
                time=f"{now:%H:%M:%S}"
            )
        )
    )


def cmd_date(*args):

    now = datetime.now()

    print(
        style(
            "main",
            t(
                "date",
                state.settings,
                date=f"{now:%d.%m.%Y}"
            )
        )
    )


def roll(*args):

    try:

        if len(args) != 2:

            warning(
                t(
                    "roll_usage",
                    state.settings
                )
            )

            return

        minimum = int(args[0])
        maximum = int(args[1])

        if minimum > maximum:

            raise ValueError(
                t(
                    "min_greater_max",
                    state.settings
                )
            )

        result = random.randint(
            minimum,
            maximum
        )

        success(
            t(
                "roll_result",
                state.settings,
                result=result
            )
        )

    except ValueError as exception:

        error(
            t(
                "error",
                state.settings,
                error=exception
            )
        )


def choice(*args):

    if len(args) < 2:

        warning(
            t(
                "choice_usage",
                state.settings
            )
        )

        return

    result = random.choice(args)

    success(
        t(
            "choice_result",
            state.settings,
            result=result
        )
    )


def count(*args):

    if not args:

        warning(
            t(
                "count_usage",
                state.settings
            )
        )

        return

    success(
        t(
            "count_result",
            state.settings,
            amount=len(args)
        )
    )


def repeat(*args):

    try:

        if len(args) < 2:

            warning(
                t(
                    "repeat_usage",
                    state.settings
                )
            )

            return

        amount = int(args[0])

        if amount < 1:

            raise ValueError(
                t(
                    "repeat_positive",
                    state.settings
                )
            )

        if amount > 1000:

            raise ValueError(
                t(
                    "repeat_max",
                    state.settings
                )
            )

        text = " ".join(args[1:])

        for _ in range(amount):

            print(
                style(
                    "main",
                    text
                )
            )

    except ValueError as exception:

        error(
            t(
                "error",
                state.settings,
                error=exception
            )
        )


def echo(*args):

    if not args:

        warning(
            t(
                "echo_usage",
                state.settings
            )
        )

        return

    text = " ".join(args)

    print(
        style(
            "main",
            t(
                "echo_result",
                state.settings,
                text=text
            )
        )
    )


def say(*args):

    if not args:

        warning(
            t(
                "say_usage",
                state.settings
            )
        )

        return

    print(
        style(
            "main",
            " ".join(args)
        )
    )


def joke(*args):

    print(
        style(
            "main",
            t(
                "joke",
                state.settings
            )
        )
    )


def show_changelog(*args):

    title(
        t(
            "changelog_title",
            state.settings
        )
    )

    print(
        style(
            "main",
            f"""│ {t("changelog_new", state.settings)}
│
│ ✓ {t("changelog_01", state.settings)}
│ ✓ {t("changelog_02", state.settings)}
│ ✓ {t("changelog_03", state.settings)}
│ ✓ {t("changelog_04", state.settings)}
│ ✓ {t("changelog_05", state.settings)}
│ ✓ {t("changelog_06", state.settings)}
│ ✓ {t("changelog_07", state.settings)}
│ ✓ {t("changelog_08", state.settings)}
│ ✓ {t("changelog_09", state.settings)}
│ ✓ {t("changelog_10", state.settings)}
│ ✓ {t("changelog_11", state.settings)}
│ ✓ {t("changelog_12", state.settings)}
│ ✓ {t("changelog_13", state.settings)}
│ ✓ {t("changelog_14", state.settings)}"""
        )
    )


def cmd_exit(*args):

    set_user_offline()

    success(
        t(
            "exit",
            state.settings
        )
    )

    return "exit"
    
# =========================================================
# СПИСОК КОМАНД
# =========================================================

def cmd_list(commands, command_categories, *args):

    title(
        t(
            "commands_title",
            state.settings
        )
    )

    categorized = []

    for category, category_commands in command_categories.items():

        # Админские команды показываются только админу.

        if category == "admin" and not is_admin():
            continue

        print(
            style(
                "title",
                f"\n{t(f'category_{category}', state.settings)}"
            )
        )

        for command in category_commands:

            if command not in commands:
                continue

            categorized.append(
                command
            )

            description = command_description(
                command,
                state.settings
            )

            print(
                style(
                    "main",
                    f"│ {command:<12} — {description}"
                )
            )

    # Команды, добавленные плагинами.

    plugin_commands = [
        command
        for command in commands
        if command not in categorized
    ]

    if plugin_commands:

        print(
            style(
                "title",
                f"\n{t('category_plugins', state.settings)}"
            )
        )

        for command in plugin_commands:

            description = command_description(
                command,
                state.settings
            )

            print(
                style(
                    "main",
                    f"│ {command:<12} — {description}"
                )
            )