# =========================================================
# IMPORTS
# =========================================================

from core import state

from core.localization import t

from core.ui import (
    style,
    error,
    title
)

from database.queries import get_db_profile


# =========================================================
# ПРОФИЛЬ
# =========================================================

def show_profile(*args):

    if state.current_user is None:

        error(
            t(
                "login_required",
                state.settings
            )
        )

        return

    profile_data = get_db_profile(
        state.current_user["uuid"]
    )

    if profile_data is None:

        error(
            t(
                "profile_unavailable",
                state.settings
            )
        )

        return

    title(
        t(
            "profile_title",
            state.settings
        )
    )

    print(
        style(
            "main",
            f"👤 {profile_data['username']}"
        )
    )

    print(
        style(
            "main",
            f"🆔 {profile_data['uuid']}"
        )
    )

    print(
        style(
            "main",
            f"📅 {profile_data['created_at']}"
        )
    )

    print(
        style(
            "main",
            f"🚀 {profile_data['runs']}"
        )
    )

    if profile_data["is_admin"]:

        print(
            style(
                "main",
                "👑 Admin"
            )
        )