from core import state
from core.localization import t
from core.ui import (
    style,
    success,
    warning,
    error,
    title
)

from database.queries import set_user_status


def calculator(*args):

    if state.current_user is not None:
        set_user_status("interface")

    if len(args) >= 1:

        try:

            primer = " ".join(args)

            print(
                eval(primer)
            )

        except Exception as exception:

            error(
                t(
                    "error",
                    state.settings,
                    error=exception
                )
            )

        return

    try:

        title(
            t(
                "calculator_title",
                state.settings
            )
        )

        print(
            style(
                "main",
                f"""│ {t("calculator_mode_1", state.settings)}
│ {t("calculator_mode_2", state.settings)}
│ {t("calculator_mode_3", state.settings)}
│ {t("calculator_mode_4", state.settings)}"""
            )
        )

        mode = int(
            input(
                t(
                    "calculator_choose_mode",
                    state.settings
                )
            )
        )

        if mode == 1:

            a = int(
                input(
                    t(
                        "calculator_first_number",
                        state.settings
                    )
                )
            )

            b = int(
                input(
                    t(
                        "calculator_second_number",
                        state.settings
                    )
                )
            )

            operation = input(
                f"""
{t("calculator_operation", state.settings)}

+  +
-  -
*  *
/  /
%  %
// //

{t("calculator_operation", state.settings)}"""
            )

            if operation == "+":
                result = a + b

            elif operation == "-":
                result = a - b

            elif operation == "*":
                result = a * b

            elif operation == "/":
                result = a / b

            elif operation == "%":
                result = a % b

            elif operation == "//":
                result = a // b

            else:

                warning(
                    t(
                        "calculator_unknown_operation",
                        state.settings
                    )
                )

                return

            success(
                t(
                    "calculator_result",
                    state.settings,
                    result=result
                )
            )

        elif mode == 2:

            a = int(
                input(
                    t(
                        "calculator_number",
                        state.settings
                    )
                )
            )

            b = int(
                input(
                    t(
                        "calculator_power",
                        state.settings
                    )
                )
            )

            if abs(b) > 1000:

                raise ValueError(
                    t(
                        "power_too_large",
                        state.settings
                    )
                )

            success(
                t(
                    "calculator_result",
                    state.settings,
                    result=a ** b
                )
            )

        elif mode == 3:

            a = int(
                input(
                    t(
                        "calculator_first_side",
                        state.settings
                    )
                )
            )

            b = int(
                input(
                    t(
                        "calculator_second_side",
                    state.settings
                    )
                )
            )

            success(
                t(
                    "calculator_perimeter",
                    state.settings,
                    result=2 * a + 2 * b
                )
            )

        elif mode == 4:

            a = int(
                input(
                    t(
                        "calculator_length",
                        state.settings
                    )
                )
            )

            b = int(
                input(
                    t(
                        "calculator_width",
                        state.settings
                    )
                )
            )

            c = int(
                input(
                    t(
                        "calculator_height",
                        state.settings
                    )
                )
            )

            success(
                t(
                    "calculator_volume",
                    state.settings,
                    result=a * b * c
                )
            )

        else:

            warning(
                t(
                    "calculator_no_mode",
                    state.settings
                )
            )

    except ValueError as exception:

        error(
            t(
                "error",
                state.settings,
                error=exception
            )
        )

    except ZeroDivisionError:

        error(
            t(
                "division_by_zero",
                state.settings
            )
        )