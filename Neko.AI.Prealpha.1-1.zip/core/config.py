# =========================================================
# CONFIG
# =========================================================

import os


# =========================================================
# DATABASE
# =========================================================

DB_HOST = "sx32e6.h.filess.io"

DB_PORT = 3306

DB_USER = "Neko AI_lasthorse"

DB_PASSWORD = "89d9ad2694b7a6afcff0ceda13ab4ab87e5d393a"

DB_NAME = "Neko AI_lasthorse"


# =========================================================
# DIRECTORIES
# =========================================================

DATA_DIR = "data"

PLUGINS_DIR = "plugins"


os.makedirs(
    DATA_DIR,
    exist_ok=True
)

os.makedirs(
    PLUGINS_DIR,
    exist_ok=True
)


# =========================================================
# LOCAL FILES
# =========================================================

NOTES_FILE = os.path.join(
    DATA_DIR,
    "notes.json"
)

TASKS_FILE = os.path.join(
    DATA_DIR,
    "tasks.json"
)

SETTINGS_FILE = os.path.join(
    DATA_DIR,
    "settings.json"
)


# =========================================================
# DEFAULT SETTINGS
# =========================================================

default_settings = {

    "username": "User",

    "language": "ru",

    "theme": "default"
}

AI_CONFIDENCE_THRESHOLD = 0.6

ai_intent_commands = {
    "greeting": "hi",
    "time": "time",
    "date": "date",
    "note_get": "notes",
    "task_get": "tasks",
    "info": "info",
    "profile": "profile",
    "settings": "settings",
    "changelog": "changelog",
    "reconnect": "reconnect",
}