import uuid

from core import state
from core.localization import t
from database.queries import username_exists, create_user
from core.security import hash_pass
from core.ui import success, warning, error

def register(*args):

    if (
        state.db is None
        or not state.db.is_connected()
    ):

        error(
            t(
                "database_required",
                state.settings
            )
        )

        return

    if len(args) != 2:

        warning(
            t(
                "register_usage",
                state.settings
            )
        )

        return

    username = args[0]
    password = args[1]

    # =====================================================
    # CHECK USERNAME
    # =====================================================

    if username_exists(username):

        error(
            t(
                "user_exists",
                state.settings
            )
        )

        return

    # =====================================================
    # CREATE USER
    # =====================================================

    user_uuid = str(
        uuid.uuid4()
    )

    password_hash, password_salt = hash_pass(
        password
    )

    if not create_user(
        user_uuid,
        username,
        password_hash,
        password_salt
    ):

        error(
            t(
                "database_error",
                state.settings
            )
        )

        return

    success(
        t(
            "register_success",
            state.settings,
            username=username
        )
    )