# =========================================================
# IMPORTS
# =========================================================

import os
import json

from core import state

from core.config import (
    SETTINGS_FILE,
    default_settings
)

from core.localization import t

from core.ui import (
    style,
    success,
    warning,
    title
)

from core.theme import themes

from database.queries import set_user_status


# =========================================================
# ЗАГРУЗКА НАСТРОЕК
# =========================================================

def load_settings():

    if os.path.exists(SETTINGS_FILE):

        with open(
            SETTINGS_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(file)

    return default_settings.copy()


# =========================================================
# СОХРАНЕНИЕ НАСТРОЕК
# =========================================================

def save_settings():

    with open(
        SETTINGS_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            state.settings,
            file,
            ensure_ascii=False,
            indent=4
        )


# =========================================================
# ПРОСМОТР НАСТРОЕК
# =========================================================

def show_settings(*args):

    if state.current_user is not None:
        set_user_status("interface")

    title(
        t(
            "settings_title",
            state.settings
        )
    )

    for name, value in state.settings.items():

        print(
            style(
                "main",
                f"│ {name}: {value}"
            )
        )


# =========================================================
# ИЗМЕНЕНИЕ НАСТРОЕК
# =========================================================

def set_setting(*args):

    if len(args) < 2:

        warning(
            t(
                "set_usage",
                state.settings
            )
        )

        return

    setting = args[0].lower()
    value = args[1].lower()

    # =====================================================
    # ПРОВЕРКА ПАРАМЕТРА
    # =====================================================

    allowed_settings = (
        "language",
        "theme"
    )

    if setting not in allowed_settings:

        warning(
            t(
                "setting_must_exist",
                state.settings
            )
        )

        return

    # =====================================================
    # LANGUAGE
    # =====================================================

    if setting == "language":

        if value not in (
            "ru",
            "en"
        ):

            warning(
                t(
                    "language_invalid",
                    state.settings
                )
            )

            return

    # =====================================================
    # THEME
    # =====================================================

    if setting == "theme":

        if value not in themes:

            warning(
                t(
                    "theme_invalid",
                    state.settings
                )
            )

            return

    # =====================================================
    # ИЗМЕНЕНИЕ
    # =====================================================

    state.settings[setting] = value

    save_settings()

    success(
        t(
            "setting_changed",
            state.settings,
            setting=setting,
            value=value
        )
    )