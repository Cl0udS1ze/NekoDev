from core import state
from core.localization import t
from core.ui import success, warning
from database.queries import set_user_offline


def logout(*args):

    if state.current_user is None:

        warning(
            t(
                "not_logged_in",
                state.settings
            )
        )

        return

    username = state.current_user["username"]

    set_user_offline()

    state.current_user = None

    success(
        t(
            "logout_success",
            state.settings,
            username=username
        )
    )