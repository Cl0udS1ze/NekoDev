from core import state
from core.localization import t
from core.security import verify_pass
from core.ui import style, success, warning, error

from database.queries import (
    cleanup_expired_moderation,
    get_user_credentials,
    increment_user_runs,
    has_unread_messages,
    set_user_status,
)

from moderation.helpers import get_moderation_text


def login(*args):

    if state.db is None or not state.db.is_connected():

        error(
            t(
                "database_required",
                state.settings
            )
        )

        return

    if state.current_user is not None:

        warning(
            t(
                "already_logged_in",
                state.settings,
                username=state.current_user["username"]
            )
        )

        return

    if len(args) != 2:

        warning(
            t(
                "login_usage",
                state.settings
            )
        )

        return

    username = args[0]
    password = args[1]

    cleanup_expired_moderation()

    user = get_user_credentials(
        username
    )

    if not user:

        error(
            t(
                "user_not_found",
                state.settings
            )
        )

        return

    user_uuid = user["uuid"]
    username = user["username"]
    password_hash = user["password_hash"]
    password_salt = user["password_salt"]
    is_admin = user["is_admin"]

    if not verify_pass(
        password,
        password_hash,
        password_salt
    ):

        error(
            t(
                "wrong_password",
                state.settings
            )
        )

        return

    increment_user_runs(
        user_uuid
    )

    ban = get_moderation_text(
        user_uuid,
        "ban"
    )

    if ban is not None:

        if ban["expires_at"] is None:

            error(
                t(
                    "account_banned_forever",
                    state.settings
                )
            )

        else:

            error(
                t(
                    "account_banned_until",
                    state.settings,
                    date=ban["expires_at"].strftime(
                        "%d.%m.%Y %H:%M"
                    )
                )
            )

        return

    state.current_user = {
        "uuid": user_uuid,
        "username": username,
        "is_admin": bool(is_admin)
    }

    set_user_status(
        "interface"
    )

    success(
        t(
            "login_success",
            state.settings,
            username=username
        )
    )

    if has_unread_messages(
    user_uuid
):

        print(
            style(
                "warning",
                t(
                    "newmessages_notification",
                    state.settings
                )
            )
        )